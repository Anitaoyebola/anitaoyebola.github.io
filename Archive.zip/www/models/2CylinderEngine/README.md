# 2 Cylinder Engine

## Screenshot

![screenshot](screenshot/screenshot.png)

## License Information

Data conversion from original JT to COLLADA has been kindly performed by Okino Computer Graphics, using [Okino Polytrans Software](http://www.okino.com/conv/conv.htm).
